from os import system
import cv2
from pdf2image import convert_from_path
import numpy as np
# import matplotlib.pyplot as plt
import pytesseract
from PIL import Image

# Global tolerance level (in pixels)
TOLERANCE = 8
# Minimum contour size to include in algorithm (Recommended bigger than avg. font size)
MIN_CONTOUR_SIZE = 18
# Max dimensions of table (in ratio to page dimension)
MAX_TABLE_RATIO = 0.5
# File Name
pdf_name = 'GAD1'

# Standard Colors
BLUE, GREEN, RED = (255, 0, 0), (0, 255, 0), (0, 0, 255)
YELLOW, CYAN, BLACK = (0, 255, 255), (255, 255, 0), (0, 0, 0)


def split_rect(rectangle):
    """ Splits a rectangle tuple into values"""
    return rectangle[0], rectangle[1], rectangle[2], rectangle[3]


def is_approx_equal(a, b, tolerance=TOLERANCE):
    """ Checks equality for given tolerance"""
    return abs(a - b) <= tolerance


def filtered_xy_list(rectangles, target):
    """ Returns rectangles contained inside the target zone"""
    list = []
    t_x, t_y, t_width, t_height = split_rect(target)
    y_upper = t_y + t_height
    x_upper = t_x + t_width
    for r in rectangles:
        if (r[1] > t_y - TOLERANCE) and (r[1] + r[3]) < (y_upper + TOLERANCE):
            if (r[0] > t_x - TOLERANCE) and (r[0] + r[2]) < (x_upper + TOLERANCE):
                list.append(r)
    return list


def has_x_overlap(rectangles):
    """ Checks for x-axis overlap in the given list"""
    rectangles.sort(key=lambda x: x[0])
    leftmost_x = 0
    for r in rectangles:
        if r[0] >= leftmost_x:
            leftmost_x = r[0] + r[2]
        else:
            return True
    return False


def sum_tuple_list(list, index):
    """ Returns the sum of a tuple list at the given index"""
    sum = 0
    for x in list:
        sum += x[index]
    return sum


def y_aligned_subset(rectangles, target):
    """ Yields a subset of rectangles adding up to target aligned on the y-axis """
    rectangles.sort(key=lambda x: x[1])
    lower_index = 0
    upper_index = 1
    while upper_index <= len(rectangles):
        sum = sum_tuple_list(rectangles[lower_index:upper_index], 2)
        tolerance = abs(TOLERANCE * (upper_index - lower_index))
        if is_approx_equal(sum, target[2], tolerance):
            lower_index += 1
            yield rectangles[lower_index-1:upper_index]
        if sum < target[2]:
            upper_index += 1
        else:
            lower_index += 1


def is_neighbor_below(top_cell, other_cell):
    """Returns true if given cell is directly below 
       (with tolerance) of the parent cell and not wider than parent cell"""
    x1, y1, w1, h1 = split_rect(top_cell)
    x2, y2, w2, _ = split_rect(other_cell)
    is_below = is_approx_equal(y1+h1, y2, TOLERANCE)
    is_fitting = x1 - TOLERANCE <= x2 and (x1 + w1 + TOLERANCE) >= (x2 + w2)
    # print('~~~~\ntop, other', top_cell, other_cell)
    # print('below, fitting', is_below, is_fitting)
    return is_below and is_fitting


def is_neighbor_right(left_cell, other_cell):
    """Returns true if given cell is directly to the right 
       (with tolerance) of the parent cell and not wider than parent cell"""
    x1, y1, w1, h1 = split_rect(left_cell)
    x2, y2, w2, h2 = split_rect(other_cell)
    is_right = is_approx_equal(x1+w1, x2, TOLERANCE*2)
    is_fitting = is_approx_equal(y1, y2, TOLERANCE)
    return is_right and is_fitting


def get_below_neighbors(rectangles, top_cell):
    """ Returns a list of neighbors""" 
    cells = []
    for r in rectangles:
        if is_neighbor_below(top_cell, r):
            cells.append(r)
    return cells


def print_rect(im, rect, color=YELLOW, width=2):
    x, y, w, h = split_rect(rect)
    cv2.rectangle(im, (x, y), (x+w, y+h), color, width)


def subset_sum(rectangles, target, partial=[], partial_sum=0):
    # Generator function to find possible combinations of rectangles
    target_width = target[2]
    if is_approx_equal(partial_sum, target_width, TOLERANCE * len(partial)):
        yield partial
    if partial_sum > target_width:
        return
    for i, n in enumerate(rectangles):
        remaining = rectangles[(i+1):]
        yield from subset_sum(remaining, target, partial + [n], partial_sum + n[2])


def merge_tables(first, second):
    if len(second) > len(first):
        temp = first
        first = second
        second = temp
    # print('lengths of merge tables', len(first), len(second))
    # Assumes first > second
    for row_idx in range(len(second)):
        row_left = first[row_idx]
        row_right = second[row_idx]
        first[row_idx] = row_left + row_right
    return first


IMG_PATH = 'C:/DataExtraction/'+pdf_name+'.pdf'
print('Reading PDF file', IMG_PATH)

ext_image = convert_from_path(IMG_PATH)[0]

img_name = pdf_name+'-img.png'

ext_image.save(img_name)
print('Converted pdf to image: ', img_name)

image = cv2.imread(img_name)

im1 = cv2.imread(img_name, 0)
im = cv2.imread(img_name)

print('size', im1.shape)
img_width = im1.shape[1]
img_height = im1.shape[0]

ret, thresh_value = cv2.threshold(im1, 180, 255, cv2.THRESH_BINARY_INV)

# cv2.waitKey(0)
kernel = np.ones((5, 5), np.uint8)
dilated_value = cv2.dilate(thresh_value, kernel, iterations=1)

contours, hierarchy = cv2.findContours(
    dilated_value, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
rectangles = []
for cnt in contours:
    # bounding the images
    x, y, w, h = cv2.boundingRect(cnt)
    if w > (MAX_TABLE_RATIO*img_width):
        continue
    if h > MIN_CONTOUR_SIZE:
        rectangles.append((x, y, w, h))
        cv2.rectangle(im, (x, y), (x+w, y+h), RED, 1)
        # print(x, y, w, h)

# print('rectangles', rectangles)


def grow_vertically(rectangles, parent_row_rect, table=[]):
    """Grows a table vertically (adds rows given top cell)"""
    print('=== GROW_VERT ===')
    print('parent row', parent_row_rect)
    x, y, w, h = split_rect(parent_row_rect)
    target_area = (x, y+h, w, 4*h)
    print('target area', target_area)
    # print('no. of rectangles to search', len(rectangles))
    # print('they are', rectangles, '\n')

    xy_filtered = filtered_xy_list(rectangles, target_area)
    next_row_cells = get_below_neighbors(xy_filtered, parent_row_rect)
    print('xy filtered', len(next_row_cells))
    if len(table) == 0:
        table.append([parent_row_rect])
    if len(next_row_cells) == 0:
        print('no more cells found')
        return table
    left_edge, right_edge = (im.shape[0], 0, 0, 0), (0, 0, 0, 0)
    row_added = False
    print('length of cell corpus', len(next_row_cells))
    count = 0
    for combination in subset_sum(next_row_cells, parent_row_rect):
        # print('combination: ', com)
        count += 1
        if len(combination) < 1:
            print('empty combination')
            continue
        if has_x_overlap(combination):
            print('overlap', combination)
            continue
        combination.sort(key=lambda x: x[0])
        left_edge = combination[0]
        right_edge = combination[-1]
        print('row found:', combination)
        table.append(combination)
        row_added = True
        break
    print('combinations tested:' , count)    
    if not row_added:
        print('no more rows')
        return table

    new_parent = (left_edge[0],
                  left_edge[1],
                  right_edge[0] + right_edge[2] - left_edge[0],
                  right_edge[1] + right_edge[3] - left_edge[1])
    # print('new parent', new_parent)
    return grow_vertically(rectangles, new_parent, table)


# Sort based on x, then y
rectangles.sort(key=lambda x: x[0])
rectangles.sort(key=lambda x: x[1])
# rectangles = rectangles[::-1]
# print('sorted', rectangles)
tables = []
total_cell_count = 0
for index in range(len(rectangles)):
    if(len(rectangles) == 0):
        break
    print('=== MAIN LOOP ===')
    parent_cell = rectangles[0]
    print('target rectangle', parent_cell)
    table = grow_vertically(rectangles, parent_cell, [])
    print('=== BACK TO MAIN LOOP ===')
    # print('table', table)
    cellCount = 0
    for row in table:
        for cell in row:
            cellCount += 1
            try:
                rectangles.remove(cell)
            except ValueError:
                pass
    # print('cell count', cellCount)
    if cellCount <= 1:
        continue
    total_cell_count += cellCount
    if len(tables) > 0:
        for t in tables:
            # Check if top cell and last cell are neighbors
            if is_neighbor_right(t[0][-1], parent_cell) and is_approx_equal(t[-1][-1][1], table[-1][-1][1]):
                new_table = merge_tables(t, table)
                tables.remove(t)
                table = new_table
                break
    tables.append(table)


# Color tables
green = True
for table in tables:
    color = GREEN
    print('t first', table[0][0])
    if not green:
        color = CYAN
    green = not green
    for row in table:
        for cell in row:
            x, y, w, h = split_rect(cell)
            cv2.rectangle(im, (x, y), (x+w, y+h), color, 3)

# x, y, w, h = 3814, 168, 806, 34
# cv2.rectangle(im, (x, y), (x+w, y+h), YELLOW, 5)

contour_img_name = pdf_name+'Alg2-output.jpg'
cv2.imwrite(contour_img_name, im)
print('Printed contour analysis to file: ', contour_img_name)

print('Tables detected:', len(tables))
print('total cells found:', total_cell_count)
# print(tables)
# Stopping Text Recog while working on contour analysis
exit()
print('Running Text Recognition...')

def get_table_strings(tables):
    tables_strs = []
    for x in tables:
        table_str = ''
        for row in x:
            row_str = ''
            for cell in row:
                x, y, w, h = split_rect(cell)
                BORDER_CROP = 2
                crop_img = im1[y + BORDER_CROP: y+h -
                               BORDER_CROP, x + BORDER_CROP:x+w-BORDER_CROP]
                # ret, img_bin = cv2.threshold(crop_img, 180, 255, cv2.THRESH_BINARY_INV)
                img_bin = crop_img
                custom_config = r'--oem 3 --psm 6'
                cell_str = ''
                try:
                    cell_str = pytesseract.image_to_string(
                        img_bin, config=custom_config)
                except:
                    print('Unable to process text')
                    continue
                cell_str = cell_str[:-2]
                row_str = row_str + cell_str + ','
            table_str = table_str + row_str[:-1] + '\n'
        # print(table_str)
        tables_strs.append(table_str)
    return tables_strs


tables_strs = get_table_strings(tables)

with open(pdf_name+"-out.csv", "w") as text_file:
    for table_str in tables_strs:
        print(table_str)
        print(table_str, file=text_file)

print('End')

# TODO
# Merges are height independent - two columns with differing heights are merged
